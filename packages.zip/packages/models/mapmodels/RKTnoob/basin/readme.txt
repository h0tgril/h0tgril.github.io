basin.md3 created by RKTnoob. 
Unwrapped and skinned by Z3R0.