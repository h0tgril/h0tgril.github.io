Model by Jean Ayers, 2012

This skull model and its textures are released under Creative Commons Attribution-ShareAlike 3.0 (http://creativecommons.org/licenses/by-sa/3.0/us/).