Thanks for downloading my mapmodel called: Candle
It can add a very mystical, and creepy atmosphere to some maps.

Feel free to use, distribute and change my mod, but please name the creator (Dementium4ever) . 
(And don`'t use it commercial !)

Everything of this mod is created by me, even the textures.

Programms used: 

Misfit Model 3D: 3D Model
Unwrapping: Lithunwrap
The simple texture: Gimp


Have fun: Dementium4ever
