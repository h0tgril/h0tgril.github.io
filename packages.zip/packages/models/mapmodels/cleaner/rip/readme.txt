LICENSE

Model R.I.P. helmet by "DES|Cleaner" for AssaultCube
e-mail: totally_shameless@hotmail.fr

Original AssaultCube rifle model and skin by makkE.

If you are using my material outside than AssaultCube I would pretty much appreciate that you send me some screenshots.

For more free textures and 3D mapmodels visit AKIMBO:
http://www.ac-akimbo.net (licenses may vary)

AssaultCube: 
http://assault.cubers.net/

***********************************************
These files have been licensed under a the
"Creative Commons Deed / Attribution Non-commercial Share-Alike ( at-nc-sa )" 

You are free:

    * to copy, distribute, display, and perform the work
    * to make derivative works

Under the following conditions:

"by" 	 -Attribution. You must give the original author credit.

"nc"	 -Non-Commercial. You may not use this work for commercial purposes.

"sa" 	 -Share Alike. If you alter, transform, or build upon this work,you may distribute the resulting work only under a licence identical to this one.

    * For any reuse or distribution, you must make clear to others the licence terms of this work.

***********************************************
