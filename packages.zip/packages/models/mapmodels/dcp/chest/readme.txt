           

creator:	dcp / http://www.dietmarpier.
Converted in .md3 by Cleaner

copyright:	the models were created to use for eveyone who likes
		to put some of them in his levels. if you want to use
		them for something else than cube, please drop me a
		line, i just want to know...

	


