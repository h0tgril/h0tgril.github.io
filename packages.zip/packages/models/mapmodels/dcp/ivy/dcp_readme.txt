model .md2
designed for use in the game cube using milkshape 3D
		           

creator:	dcp / dietmar pier

copyright:	the models were created to use for eveyone who likes to put some of them in his levels. if you want to use them for something else than cube, please drop me a line, i just want to know...

credits:	wouter van oordmerssen aka aardappel
