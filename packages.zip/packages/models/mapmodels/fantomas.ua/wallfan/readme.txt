LICENSE

Built-in wallfan animated model by "FANTOMAS.UA" for AssaultCube using 3DS Max & Fragmotion.
e-mail: drdrbox@gmail.com

Free Textures & Sound sources are taken from Internet.

If you are using my material outside than AssaultCube I would pretty much appreciate that you send me some screenshots.

AssaultCube: 
http://assault.cubers.net

***********************************************
These file has been licensed under a the
"Creative Commons Deed / Attribution Non-commercial Share-Alike ( at-nc-sa )" 

You are free:

    * to copy, distribute, display, and perform the work
    * to make derivative works

Under the following conditions:

"by" 	 -Attribution. You must give the original author credit.

"nc"	 -Non-Commercial. You may not use this work for commercial purposes.

"sa" 	 -Share Alike. If you alter, transform, or build upon this work,you may distribute the resulting work only under a licence identical to this one.

    * For any reuse or distribution, you must make clear to others the licence terms of this work.

***********************************************
