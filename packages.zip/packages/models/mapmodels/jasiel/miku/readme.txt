The mapmodel was originally created by cleaner as "cleaner/monalisa".
The "Hatsune Miku" image is copyrighted by Cripton Future Media, Inc.
The use of Hatsune Miku image is free for non-commercial purposes.
