This mapmodel was based in "toca/tree2" mapmodel. Only the skin was edited, the model is the original.

Edition by Jasiel.