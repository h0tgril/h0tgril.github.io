The mapmodel is taken from http://www.md2.sitters-electronics.nl / edited and exported to md3 by SrPER$IAN.

	

