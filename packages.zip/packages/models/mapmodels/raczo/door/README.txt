To use this model you need to assign a texture to it. I should be a texture of a door ^^ 
