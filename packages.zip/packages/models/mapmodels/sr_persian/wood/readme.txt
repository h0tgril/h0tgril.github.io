The model is made by SrPER$IAN for Assault Cube.

	
=======================================================================
All mapmodels are licensed under the Creative Commons.

"Attribution-NonCommercial-ShareAlike 3.0" Unported" (AT-NC-SA) license.

http://creativecommons.org/licenses/by-nc-sa/3.0/

This means you are free to share, copy, distribute, transmit & to remix/adapt the work, under the following conditions:
 * Attribution: You must attribute the work in the manner specified by 
   the author or licensor (but not in any way that suggests that they endorse you or your use of the work).

 * Noncommercial:	You may not use this work for commercial purposes.
 * Share Alike: If you alter, transform, or build upon this work, you
   may distribute the resulting work only under the same or similar    license to this one.

To view a copy of the full licenses legal code, visit:
http://creativecommons.org/licenses/by-nc-sa/3.0/legalcode

