The map model is taken from http://www.3dxtras.com/ and edited and exported to md3 by SrPER$IAN.
Original model had some strange issues so was edited by Z3R0 for use in ac_roots.

