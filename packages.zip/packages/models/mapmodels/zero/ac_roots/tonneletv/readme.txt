Model originally created by Boeufmironton for use in ac_souk.
Model's skin was edited for use in ac_roots by Z3R0.