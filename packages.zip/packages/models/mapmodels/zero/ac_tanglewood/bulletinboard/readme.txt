Model bulletinboard created by Z3R0.
board.jpg texture is a modification of Nieb's tetxure planksold001 for use with model bulletinboard.