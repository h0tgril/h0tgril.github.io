Model statue by Z3R0.
Model uses Assault Cube's playermodel and a modified version of Protox's assault cube player skins.
Also assaultcube's flag model and a modified version of it's skin.